// Cleaned Gemini service: frontend only talks to your FastAPI backend.
// It no longer uses @google/genai or accesses GEMINI_API_KEY directly.

export const extractTextFromImage = async (file: File): Promise<string> => {
  // TODO: connect this to your local OCR backend when it's ready.
  console.warn("extractTextFromImage: OCR not implemented yet, returning placeholder text.");
  return "OCR from image is not implemented yet. Please manually verify or edit the extracted Devanagari text.";
};

export const generateSummary = async (text: string): Promise<string> => {
  try {
    const res = await fetch("http://127.0.0.1:8000/process", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text }),
    });

    if (!res.ok) {
      throw new Error(`Backend error: ${res.status}`);
    }

    const data = (await res.json()) as {
      original_text: string;
      summary_english: string;
    };

    return data.summary_english ?? "No summary available.";
  } catch (error) {
    console.error("Summary Error:", error);
    return "Unable to generate summary at this time.";
  }
};
