
export interface ScanResult {
  id: string;
  timestamp: number;
  extractedText: string;
  summary: string;
}

const STORAGE_KEY = 'devascan_history';

export const saveScan = (text: string, summary: string): void => {
  const newScan: ScanResult = {
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    extractedText: text,
    summary: summary
  };
  const existing = getScans();
  const updated = [newScan, ...existing];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const getScans = (): ScanResult[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
};

export const deleteScan = (id: string): void => {
    const existing = getScans();
    const updated = existing.filter(scan => scan.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const clearLibrary = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};
