
import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import OcrInterface from './components/OcrInterface';
import Library from './components/Library';
import Settings from './components/Settings';
import Help from './components/Help';

export type View = 'home' | 'ocr' | 'library' | 'settings' | 'help';

const App: React.FC = () => {
  const [view, setView] = useState<View>('home');

  return (
    <div className="bg-brand-dark min-h-screen text-gray-200 font-sans selection:bg-brand-orange/50 selection:text-white">
      <div className="absolute inset-0 -z-0 h-full w-full bg-brand-dark bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]"></div>
      <div className="relative z-10">
        <Header onNavigate={(view) => setView(view)} />
        <main className="container mx-auto px-4 py-8 md:py-16">
          {view === 'home' && <Hero onGetStarted={() => setView('ocr')} />}
          {view === 'ocr' && <OcrInterface />}
          {view === 'library' && <Library />}
          {view === 'settings' && <Settings />}
          {view === 'help' && <Help />}
        </main>
      </div>
    </div>
  );
};

export default App;
