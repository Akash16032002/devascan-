
import React, { useEffect, useState } from 'react';
import { getScans, ScanResult, deleteScan } from '../services/libraryService';
import { TrashIcon, ClockIcon, FileIcon, WandIcon } from './icons';

const Library: React.FC = () => {
    const [scans, setScans] = useState<ScanResult[]>([]);

    useEffect(() => {
        setScans(getScans());
    }, []);

    const handleDelete = (id: string) => {
        deleteScan(id);
        setScans(getScans());
    };

    if (scans.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[400px] text-gray-500">
                <FileIcon className="w-16 h-16 mb-4 opacity-50" />
                <h3 className="text-xl font-semibold mb-2">Library is Empty</h3>
                <p>Scanned documents and summaries will appear here.</p>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-center justify-between border-b border-brand-border pb-4">
                <h2 className="text-3xl font-bold text-white">My Library</h2>
                <span className="text-sm text-gray-400">{scans.length} Items</span>
            </div>
            
            <div className="grid gap-6">
                {scans.map(scan => (
                    <div key={scan.id} className="bg-brand-secondary border border-brand-border rounded-xl p-6 transition-all hover:border-brand-orange/30 group">
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex items-center gap-2 text-sm text-gray-400 bg-brand-dark/50 px-3 py-1 rounded-full">
                                <ClockIcon className="w-4 h-4" />
                                {new Date(scan.timestamp).toLocaleString()}
                            </div>
                            <button 
                                onClick={() => handleDelete(scan.id)}
                                className="text-gray-500 hover:text-red-400 transition-colors p-2 rounded-lg hover:bg-brand-dark/50"
                                title="Delete Scan"
                            >
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <h4 className="text-sm font-semibold text-brand-orange uppercase tracking-wider">Mapped Text</h4>
                                <div className="bg-brand-dark/50 p-4 rounded-lg border border-brand-border/50 h-32 overflow-y-auto font-mono text-sm text-gray-300">
                                    {scan.extractedText}
                                </div>
                            </div>
                            
                            <div className="space-y-2">
                                <h4 className="text-sm font-semibold text-purple-400 uppercase tracking-wider flex items-center gap-2">
                                    <WandIcon className="w-3 h-3" /> Summary
                                </h4>
                                <div className="bg-brand-dark/50 p-4 rounded-lg border border-brand-border/50 h-32 overflow-y-auto text-sm text-gray-300">
                                    {scan.summary || "No summary available."}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Library;
