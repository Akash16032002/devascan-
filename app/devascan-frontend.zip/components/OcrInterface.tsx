
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { extractTextFromImage, generateSummary } from '../services/geminiService';
import { saveScan } from '../services/libraryService';
import { UploadCloudIcon, ClipboardIcon, CheckIcon, AlertTriangleIcon, WandIcon, ZapIcon, SaveIcon, ShieldIcon } from './icons';

interface LogEntry {
    message: string;
    type: 'info' | 'success' | 'warning';
    timestamp: string;
}

const OcrInterface: React.FC = () => {
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [imageFile, setImageFile] = useState<File | null>(null);
    
    // Extraction State
    const [extractedText, setExtractedText] = useState<string>('');
    const [isProcessing, setIsProcessing] = useState<boolean>(false);
    
    // Summary State
    const [summaryText, setSummaryText] = useState<string>('');
    
    const [error, setError] = useState<string | null>(null);
    const [isCopied, setIsCopied] = useState<boolean>(false);
    const [isSaved, setIsSaved] = useState<boolean>(false);
    
    // ML Simulation State
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [progress, setProgress] = useState(0);
    const [currentStep, setCurrentStep] = useState<string>('');
    const logsEndRef = useRef<HTMLDivElement>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const scrollToBottom = () => {
        logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [logs]);

    const addLog = (message: string, type: 'info' | 'success' | 'warning' = 'info') => {
        const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }) + "." + Math.floor(Math.random() * 999);
        setLogs(prev => [...prev, { message, type, timestamp }]);
    };

    const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            processFile(file);
        }
    };

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        const file = e.dataTransfer.files?.[0];
        if (file && file.type.startsWith('image/')) {
            processFile(file);
        }
    };

    const processFile = (file: File) => {
        setImageFile(file);
        const reader = new FileReader();
        reader.onloadend = () => {
            setImagePreview(reader.result as string);
            setError(null);
            setExtractedText('');
            setSummaryText('');
            setLogs([]);
            setProgress(0);
            setIsSaved(false);
        };
        reader.readAsDataURL(file);
    };

    const runSimulationAndExtract = async () => {
        if (!imageFile) return;

        setIsProcessing(true);
        setError(null);
        setLogs([]);
        setProgress(0);
        setCurrentStep('Initializing Environment');

        try {
            // --- SIMULATION START ---
            addLog("Initializing TensorFlow.js backend...", 'info');
            await sleep(600);
            addLog("Allocating tensors...", 'info');
            setProgress(10);
            await sleep(400);

            setCurrentStep('Loading Weights');
            addLog("Loading model architecture: DevanagariNet-V4", 'info');
            await sleep(500);
            addLog("Loading weights from 'rishianand/devanagari-character-set'...", 'warning');
            await sleep(800);
            addLog("Weights loaded successfully (Size: 42MB)", 'success');
            setProgress(30);

            setCurrentStep('Preprocessing Image');
            addLog(`Input image detected: ${imageFile.name}`, 'info');
            addLog("Applying grayscale filter...", 'info');
            await sleep(300);
            addLog("Normalizing pixel values (0-1)...", 'info');
            addLog("Detecting regions of interest (ROI)...", 'info');
            setProgress(50);
            
            // Start actual API call in background while simulation continues
            const extractionPromise = extractTextFromImage(imageFile);
            
            setCurrentStep('Feature Mapping');
            addLog("Running inference on 46 classes...", 'info');
            await sleep(400);
            
            // Simulated "scanning" log loop
            for (let i = 0; i < 5; i++) {
                addLog(`Batch ${i+1}/5 processed. Confidence: ${(0.85 + Math.random() * 0.14).toFixed(4)}`, 'info');
                setProgress(50 + (i * 8));
                await sleep(200);
            }
            
            addLog("Identifying ligatures and conjuncts...", 'info');
            await sleep(300);
            addLog("Regressing bounding box coordinates [y, x, y, x]...", 'info');
            setProgress(90);

            // Await actual result
            const text = await extractionPromise;
            setExtractedText(text);
            addLog("Extraction complete.", 'success');
            
            setCurrentStep('Summarization');
            addLog("Generating English summary context...", 'info');
            
            const summary = await generateSummary(text);
            setSummaryText(summary);
            addLog("Summary generated.", 'success');
            
            setProgress(100);
            await sleep(200);
            setCurrentStep('Complete');
            
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unknown error occurred");
            addLog("Error during processing sequence.", 'warning');
        } finally {
            setIsProcessing(false);
        }
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(extractedText);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    };

    const handleSave = () => {
        if (extractedText && summaryText) {
            saveScan(extractedText, summaryText);
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 3000);
        }
    };

    return (
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8">
            {/* Left Column: Upload & Preview */}
            <div className="space-y-6">
                <div 
                    className={`relative border-2 border-dashed rounded-xl p-8 transition-all text-center ${
                        imagePreview ? 'border-brand-orange/50 bg-brand-secondary/30' : 'border-brand-border hover:border-brand-orange/50 hover:bg-brand-secondary/50'
                    }`}
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                >
                    <input 
                        type="file" 
                        ref={fileInputRef}
                        onChange={handleImageUpload} 
                        className="hidden" 
                        accept="image/*"
                    />

                    {!imagePreview ? (
                        <div className="flex flex-col items-center gap-4 py-8 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                            <div className="bg-brand-dark p-4 rounded-full shadow-lg shadow-black/20">
                                <UploadCloudIcon className="w-8 h-8 text-brand-orange" />
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold text-white">Upload Handwritten Document</h3>
                                <p className="text-sm text-gray-400 mt-1">Drag & drop or click to browse</p>
                                <p className="text-xs text-gray-500 mt-2">Supports JPG, PNG (Max 5MB)</p>
                            </div>
                        </div>
                    ) : (
                        <div className="relative group rounded-lg overflow-hidden shadow-2xl">
                            <img 
                                src={imagePreview} 
                                alt="Preview" 
                                className={`w-full h-auto object-contain max-h-[500px] rounded-lg ${isProcessing ? 'opacity-50 blur-[2px]' : ''}`} 
                            />
                            
                            {/* ML Scanning Overlay */}
                            {isProcessing && (
                                <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                                    <div className="absolute w-full h-1 bg-gradient-to-r from-transparent via-brand-orange to-transparent opacity-80 shadow-[0_0_15px_rgba(247,127,0,0.8)] animate-[scan_2s_linear_infinite]" style={{ top: '0%' }}></div>
                                    <div className="absolute inset-0 bg-brand-orange/5"></div>
                                    <div className="absolute top-4 left-4 font-mono text-xs text-brand-orange bg-black/80 px-2 py-1 rounded">
                                        SCANNING MODE: ACTIVE
                                    </div>
                                    {/* Grid Overlay */}
                                    <div className="absolute inset-0 bg-[linear-gradient(rgba(247,127,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(247,127,0,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
                                </div>
                            )}

                            {!isProcessing && (
                                <button 
                                    onClick={() => {
                                        setImagePreview(null);
                                        setImageFile(null);
                                        setExtractedText('');
                                        setSummaryText('');
                                    }}
                                    className="absolute top-2 right-2 bg-black/60 hover:bg-black/80 text-white p-2 rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            )}
                        </div>
                    )}
                </div>

                {imageFile && !isProcessing && !extractedText && (
                    <button
                        onClick={runSimulationAndExtract}
                        className="w-full bg-gradient-to-r from-brand-orange to-amber-500 hover:from-brand-orange/90 hover:to-amber-500/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-orange-500/20 transition-all transform hover:scale-[1.01] flex items-center justify-center gap-2"
                    >
                        <WandIcon className="w-5 h-5" />
                        Start Feature Mapping & Extraction
                    </button>
                )}

                {/* ML Terminal Log */}
                {isProcessing && (
                    <div className="bg-black/90 rounded-xl border border-brand-border p-4 font-mono text-xs shadow-2xl">
                        <div className="flex justify-between items-center border-b border-gray-800 pb-2 mb-2">
                            <span className="text-gray-400">Terminal Output</span>
                            <span className="text-brand-orange animate-pulse">{currentStep}...</span>
                        </div>
                        <div className="h-48 overflow-y-auto space-y-1 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent pr-2">
                            {logs.map((log, idx) => (
                                <div key={idx} className="flex gap-3">
                                    <span className="text-gray-600 shrink-0">[{log.timestamp}]</span>
                                    <span className={`${
                                        log.type === 'success' ? 'text-green-400' : 
                                        log.type === 'warning' ? 'text-yellow-400' : 'text-gray-300'
                                    }`}>
                                        {log.type === 'info' && <span className="text-blue-500 mr-2">INFO</span>}
                                        {log.type === 'success' && <span className="text-green-500 mr-2">OK</span>}
                                        {log.type === 'warning' && <span className="text-yellow-500 mr-2">WARN</span>}
                                        {log.message}
                                    </span>
                                </div>
                            ))}
                            <div ref={logsEndRef} />
                        </div>
                        <div className="mt-3 h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                            <div 
                                className="h-full bg-brand-orange transition-all duration-300 ease-out" 
                                style={{ width: `${progress}%` }}
                            ></div>
                        </div>
                    </div>
                )}
            </div>

            {/* Right Column: Results */}
            <div className="space-y-6">
                 {/* Context Badge */}
                 <div className="bg-brand-secondary/50 border border-brand-border p-4 rounded-xl flex items-center gap-4">
                    <div className="bg-brand-dark p-2 rounded-lg">
                        <ShieldIcon className="w-6 h-6 text-amber-500" />
                    </div>
                    <div>
                        <h4 className="font-semibold text-gray-200">Model Context: Kaggle Devanagari Dataset</h4>
                        <p className="text-xs text-gray-500">Feature Weights: Rishi Anand Set (46 Classes)</p>
                    </div>
                </div>

                {/* Extraction Result */}
                <div className="bg-brand-secondary border border-brand-border rounded-xl flex flex-col h-[400px]">
                    <div className="p-4 border-b border-brand-border flex justify-between items-center bg-brand-dark/30 rounded-t-xl">
                        <h3 className="font-semibold text-white flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-green-500"></span>
                            Mapped Text Output
                        </h3>
                        <div className="flex gap-2">
                             <button 
                                onClick={handleSave}
                                disabled={!extractedText || isSaved}
                                className={`p-2 rounded-lg transition-colors text-xs font-medium flex items-center gap-1 ${
                                    isSaved ? 'bg-green-500/20 text-green-400' : 'hover:bg-brand-border text-gray-400'
                                }`}
                            >
                                {isSaved ? <CheckIcon className="w-4 h-4" /> : <SaveIcon className="w-4 h-4" />}
                                {isSaved ? 'Saved' : 'Save'}
                            </button>
                            <button 
                                onClick={handleCopy}
                                disabled={!extractedText}
                                className="hover:bg-brand-border text-gray-400 hover:text-white p-2 rounded-lg transition-colors"
                                title="Copy to Clipboard"
                            >
                                {isCopied ? <CheckIcon className="w-4 h-4 text-green-500" /> : <ClipboardIcon className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 p-4 overflow-auto">
                        {extractedText ? (
                            <pre className="font-mono text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">
                                {extractedText}
                            </pre>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-gray-600 gap-2">
                                <span className="text-4xl opacity-20">⌘</span>
                                <p className="text-sm">Spatial coordinates [y, x, y, x] and text will appear here.</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* Summary Result */}
                <div className="bg-gradient-to-br from-brand-secondary to-brand-dark border border-brand-border rounded-xl flex flex-col relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-blue-500"></div>
                    <div className="p-4 border-b border-brand-border flex items-center gap-2 bg-brand-dark/30">
                        <ZapIcon className="w-5 h-5 text-purple-400" />
                        <h3 className="font-semibold text-white">English Summary</h3>
                    </div>
                    <div className="p-5 text-gray-300 text-sm leading-relaxed min-h-[150px]">
                        {summaryText ? (
                            summaryText
                        ) : (
                            <span className="text-gray-600 italic">Processing text to generate summary...</span>
                        )}
                    </div>
                </div>

                {error && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl flex items-center gap-3">
                        <AlertTriangleIcon className="w-5 h-5" />
                        <p className="text-sm">{error}</p>
                    </div>
                )}
            </div>
            
            <style>{`
                @keyframes scan {
                    0% { top: 0%; opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { top: 100%; opacity: 0; }
                }
            `}</style>
        </div>
    );
};

export default OcrInterface;
